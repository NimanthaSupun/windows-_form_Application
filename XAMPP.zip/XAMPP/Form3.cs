﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace XAMPP
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            this.panel1.Paint += new PaintEventHandler(panel1_Paint);


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginSuccessForm ls = new LoginSuccessForm();
            ls.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm frm1 = new LoginForm();
            frm1.ShowDialog();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            /*

            if (radioButton1.Checked)
            {
                MessageBox.Show("Patient Preference", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            */
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            /*
            if(!radioButton2.Checked)
            {
                MessageBox.Show("No Patient Preference", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            */
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

            Graphics g = e.Graphics;

            Rectangle rect = this.panel1.ClientRectangle;

            Color color1 = Color.White;
            Color color2 = Color.White;


            using(LinearGradientBrush brush = new LinearGradientBrush(rect, color1, color2, 90F))
            {
                g.FillRectangle(brush, rect);   
            }



        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(radioButton1.Checked== true)
            {
                MessageBox.Show("Patient Preference", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
            if (radioButton2.Checked== true)
            {
                MessageBox.Show("No Patient Preference", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }

            this.Hide();
            Form4 f4 = new Form4();
            f4.Show();



        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
