﻿namespace XAMPP
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtOName = new System.Windows.Forms.TextBox();
            this.txtONo = new System.Windows.Forms.TextBox();
            this.txtOAddress = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtOAge = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOT = new System.Windows.Forms.TextBox();
            this.txtOTlabel = new System.Windows.Forms.Label();
            this.txtOC = new System.Windows.Forms.TextBox();
            this.txtClabel = new System.Windows.Forms.Label();
            this.grpOS = new System.Windows.Forms.GroupBox();
            this.rdoOMrid = new System.Windows.Forms.RadioButton();
            this.rdoOum = new System.Windows.Forms.RadioButton();
            this.rdoOMo = new System.Windows.Forms.RadioButton();
            this.grpOG = new System.Windows.Forms.GroupBox();
            this.rdoOMale = new System.Windows.Forms.RadioButton();
            this.rdoOFemale = new System.Windows.Forms.RadioButton();
            this.rdoOother = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.grpOS.SuspendLayout();
            this.grpOG.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label10);
            this.panel2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Location = new System.Drawing.Point(19, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1130, 100);
            this.panel2.TabIndex = 43;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Avenir Heavy", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(3, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 58);
            this.label1.TabIndex = 43;
            this.label1.Text = "OPD Consultation";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DimGray;
            this.label10.Location = new System.Drawing.Point(1093, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 36);
            this.label10.TabIndex = 42;
            this.label10.Text = "X";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 134);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 36);
            this.label5.TabIndex = 79;
            this.label5.Text = "Full Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(149, 36);
            this.label6.TabIndex = 80;
            this.label6.Text = "NIC Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(28, 287);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 36);
            this.label9.TabIndex = 83;
            this.label9.Text = "Address";
            // 
            // txtOName
            // 
            this.txtOName.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtOName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOName.Location = new System.Drawing.Point(336, 140);
            this.txtOName.Name = "txtOName";
            this.txtOName.Size = new System.Drawing.Size(769, 30);
            this.txtOName.TabIndex = 85;
            // 
            // txtONo
            // 
            this.txtONo.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtONo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtONo.Location = new System.Drawing.Point(336, 194);
            this.txtONo.Name = "txtONo";
            this.txtONo.Size = new System.Drawing.Size(769, 30);
            this.txtONo.TabIndex = 86;
            // 
            // txtOAddress
            // 
            this.txtOAddress.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtOAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOAddress.Location = new System.Drawing.Point(336, 287);
            this.txtOAddress.Name = "txtOAddress";
            this.txtOAddress.Size = new System.Drawing.Size(769, 30);
            this.txtOAddress.TabIndex = 88;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(28, 237);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 36);
            this.label14.TabIndex = 91;
            this.label14.Text = "Age";
            // 
            // txtOAge
            // 
            this.txtOAge.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtOAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOAge.Location = new System.Drawing.Point(336, 239);
            this.txtOAge.Name = "txtOAge";
            this.txtOAge.Size = new System.Drawing.Size(769, 30);
            this.txtOAge.TabIndex = 92;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtOT);
            this.panel1.Controls.Add(this.txtOTlabel);
            this.panel1.Controls.Add(this.txtOC);
            this.panel1.Controls.Add(this.txtClabel);
            this.panel1.Controls.Add(this.grpOS);
            this.panel1.Controls.Add(this.grpOG);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.txtOAge);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.txtOAddress);
            this.panel1.Controls.Add(this.txtONo);
            this.panel1.Controls.Add(this.txtOName);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(-5, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1166, 968);
            this.panel1.TabIndex = 43;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 510);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 36);
            this.label2.TabIndex = 101;
            this.label2.Text = "or Injury";
            // 
            // txtOT
            // 
            this.txtOT.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtOT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOT.Location = new System.Drawing.Point(336, 616);
            this.txtOT.Multiline = true;
            this.txtOT.Name = "txtOT";
            this.txtOT.Size = new System.Drawing.Size(769, 140);
            this.txtOT.TabIndex = 100;
            // 
            // txtOTlabel
            // 
            this.txtOTlabel.AutoSize = true;
            this.txtOTlabel.BackColor = System.Drawing.Color.Transparent;
            this.txtOTlabel.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOTlabel.Location = new System.Drawing.Point(28, 614);
            this.txtOTlabel.Name = "txtOTlabel";
            this.txtOTlabel.Size = new System.Drawing.Size(126, 36);
            this.txtOTlabel.TabIndex = 99;
            this.txtOTlabel.Text = "Treatment";
            // 
            // txtOC
            // 
            this.txtOC.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtOC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOC.Location = new System.Drawing.Point(338, 472);
            this.txtOC.Multiline = true;
            this.txtOC.Name = "txtOC";
            this.txtOC.Size = new System.Drawing.Size(769, 129);
            this.txtOC.TabIndex = 98;
            // 
            // txtClabel
            // 
            this.txtClabel.AutoSize = true;
            this.txtClabel.BackColor = System.Drawing.Color.Transparent;
            this.txtClabel.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClabel.Location = new System.Drawing.Point(28, 474);
            this.txtClabel.Name = "txtClabel";
            this.txtClabel.Size = new System.Drawing.Size(264, 36);
            this.txtClabel.TabIndex = 97;
            this.txtClabel.Text = "Particular of complaint ";
            // 
            // grpOS
            // 
            this.grpOS.BackColor = System.Drawing.Color.Transparent;
            this.grpOS.Controls.Add(this.rdoOMrid);
            this.grpOS.Controls.Add(this.rdoOum);
            this.grpOS.Controls.Add(this.rdoOMo);
            this.grpOS.Location = new System.Drawing.Point(338, 394);
            this.grpOS.Name = "grpOS";
            this.grpOS.Size = new System.Drawing.Size(446, 54);
            this.grpOS.TabIndex = 96;
            this.grpOS.TabStop = false;
            // 
            // rdoOMrid
            // 
            this.rdoOMrid.AutoSize = true;
            this.rdoOMrid.BackColor = System.Drawing.Color.Transparent;
            this.rdoOMrid.Font = new System.Drawing.Font("Avenir Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoOMrid.Location = new System.Drawing.Point(11, 12);
            this.rdoOMrid.Name = "rdoOMrid";
            this.rdoOMrid.Size = new System.Drawing.Size(110, 35);
            this.rdoOMrid.TabIndex = 70;
            this.rdoOMrid.TabStop = true;
            this.rdoOMrid.Text = "Married";
            this.rdoOMrid.UseVisualStyleBackColor = false;
            // 
            // rdoOum
            // 
            this.rdoOum.AutoSize = true;
            this.rdoOum.BackColor = System.Drawing.Color.Transparent;
            this.rdoOum.Font = new System.Drawing.Font("Avenir Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoOum.Location = new System.Drawing.Point(139, 12);
            this.rdoOum.Name = "rdoOum";
            this.rdoOum.Size = new System.Drawing.Size(133, 35);
            this.rdoOum.TabIndex = 71;
            this.rdoOum.TabStop = true;
            this.rdoOum.Text = "Unmarried";
            this.rdoOum.UseVisualStyleBackColor = false;
            // 
            // rdoOMo
            // 
            this.rdoOMo.AutoSize = true;
            this.rdoOMo.BackColor = System.Drawing.Color.Transparent;
            this.rdoOMo.Font = new System.Drawing.Font("Avenir Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoOMo.Location = new System.Drawing.Point(292, 12);
            this.rdoOMo.Name = "rdoOMo";
            this.rdoOMo.Size = new System.Drawing.Size(90, 35);
            this.rdoOMo.TabIndex = 72;
            this.rdoOMo.TabStop = true;
            this.rdoOMo.Text = "Other";
            this.rdoOMo.UseVisualStyleBackColor = false;
            // 
            // grpOG
            // 
            this.grpOG.BackColor = System.Drawing.Color.Transparent;
            this.grpOG.Controls.Add(this.rdoOMale);
            this.grpOG.Controls.Add(this.rdoOFemale);
            this.grpOG.Controls.Add(this.rdoOother);
            this.grpOG.Location = new System.Drawing.Point(338, 332);
            this.grpOG.Name = "grpOG";
            this.grpOG.Size = new System.Drawing.Size(446, 56);
            this.grpOG.TabIndex = 95;
            this.grpOG.TabStop = false;
            // 
            // rdoOMale
            // 
            this.rdoOMale.AutoSize = true;
            this.rdoOMale.BackColor = System.Drawing.Color.Transparent;
            this.rdoOMale.Font = new System.Drawing.Font("Avenir Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoOMale.Location = new System.Drawing.Point(11, 17);
            this.rdoOMale.Name = "rdoOMale";
            this.rdoOMale.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rdoOMale.Size = new System.Drawing.Size(81, 35);
            this.rdoOMale.TabIndex = 68;
            this.rdoOMale.TabStop = true;
            this.rdoOMale.Text = "Male";
            this.rdoOMale.UseVisualStyleBackColor = false;
            // 
            // rdoOFemale
            // 
            this.rdoOFemale.AutoSize = true;
            this.rdoOFemale.BackColor = System.Drawing.Color.Transparent;
            this.rdoOFemale.Font = new System.Drawing.Font("Avenir Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoOFemale.Location = new System.Drawing.Point(139, 17);
            this.rdoOFemale.Name = "rdoOFemale";
            this.rdoOFemale.Size = new System.Drawing.Size(101, 35);
            this.rdoOFemale.TabIndex = 69;
            this.rdoOFemale.TabStop = true;
            this.rdoOFemale.Text = "Female";
            this.rdoOFemale.UseVisualStyleBackColor = false;
            // 
            // rdoOother
            // 
            this.rdoOother.AutoSize = true;
            this.rdoOother.BackColor = System.Drawing.Color.Transparent;
            this.rdoOother.Font = new System.Drawing.Font("Avenir Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoOother.Location = new System.Drawing.Point(292, 17);
            this.rdoOother.Name = "rdoOother";
            this.rdoOother.Size = new System.Drawing.Size(90, 35);
            this.rdoOother.TabIndex = 73;
            this.rdoOother.TabStop = true;
            this.rdoOother.Text = "Other";
            this.rdoOother.UseVisualStyleBackColor = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(28, 404);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 36);
            this.label12.TabIndex = 94;
            this.label12.Text = "Status";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Avenir Heavy", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(28, 349);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 36);
            this.label11.TabIndex = 93;
            this.label11.Text = "Gender";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Image = global::XAMPP.Properties.Resources.icons8_power_off_button;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(19, 799);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(184, 67);
            this.button3.TabIndex = 41;
            this.button3.Text = "LOG OUT";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::XAMPP.Properties.Resources.back;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(735, 802);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(163, 64);
            this.button2.TabIndex = 40;
            this.button2.Text = "BACK";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::XAMPP.Properties.Resources.Next;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(957, 806);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 60);
            this.button1.TabIndex = 39;
            this.button1.Text = "NEXT";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1156, 963);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grpOS.ResumeLayout(false);
            this.grpOS.PerformLayout();
            this.grpOG.ResumeLayout(false);
            this.grpOG.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtOName;
        private System.Windows.Forms.TextBox txtONo;
        private System.Windows.Forms.TextBox txtOAddress;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtOAge;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtOT;
        private System.Windows.Forms.Label txtOTlabel;
        private System.Windows.Forms.TextBox txtOC;
        private System.Windows.Forms.Label txtClabel;
        private System.Windows.Forms.GroupBox grpOS;
        private System.Windows.Forms.RadioButton rdoOMrid;
        private System.Windows.Forms.RadioButton rdoOum;
        private System.Windows.Forms.RadioButton rdoOMo;
        private System.Windows.Forms.GroupBox grpOG;
        private System.Windows.Forms.RadioButton rdoOMale;
        private System.Windows.Forms.RadioButton rdoOFemale;
        private System.Windows.Forms.RadioButton rdoOother;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label2;
    }
}